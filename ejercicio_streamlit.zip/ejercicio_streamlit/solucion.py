"""Inventario del laboratorio de Química — solución de referencia.

Ejecutar desde la carpeta raíz del ejercicio (donde están reactivos.csv y static/):
    streamlit run solucion.py
"""
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

RUTA_CSV = Path("reactivos.csv")
STATIC = Path("static")
HOY = pd.Timestamp(date.today())
COLUMNAS_CSV = [
    "id", "reactivo", "formula", "categoria", "estado", "masa_molar", "pureza_pct",
    "cantidad", "unidad", "stock_minimo", "precio_100", "ubicacion", "peligro",
    "fecha_caducidad", "ficha_pdf", "pictograma",
]

st.set_page_config(page_title="Inventario de reactivos", page_icon="🧪", layout="wide")


# ---------------------------------------------------------------- Datos
@st.cache_data
def cargar(ruta):
    return pd.read_csv(ruta, parse_dates=["fecha_caducidad"])


def columnas_calculadas(df):
    df = df.copy()
    df["valor"] = (df["cantidad"] / 100 * df["precio_100"]).round(2)
    df["bajo_stock"] = df["cantidad"] < df["stock_minimo"]
    df["caducado"] = df["fecha_caducidad"] < HOY
    df["ficha_url"] = "app/static/" + df["ficha_pdf"].fillna("")
    df.loc[df["ficha_pdf"].isna() | (df["ficha_pdf"] == ""), "ficha_url"] = None
    df["picto_url"] = "app/static/" + df["pictograma"]
    return df


def guardar(df):
    df[COLUMNAS_CSV].to_csv(RUTA_CSV, index=False, date_format="%Y-%m-%d")
    cargar.clear()


# Estado de la sesión
if "inventario" not in st.session_state:
    st.session_state.inventario = cargar(RUTA_CSV)
if "pedido" not in st.session_state:
    st.session_state.pedido = []          # lista de ids

df = columnas_calculadas(st.session_state.inventario)


def nombre_de(id_):
    return df.loc[df["id"] == id_, "reactivo"].iloc[0]


# ---------------------------------------------------------------- Filtros
with st.sidebar:
    st.header("Filtros")
    texto = st.text_input("Buscar (nombre o fórmula)")
    categorias = st.multiselect("Categoría", sorted(df["categoria"].unique()))
    ubicacion = st.selectbox("Ubicación", ["Todas"] + sorted(df["ubicacion"].unique()))
    estado = st.radio("Estado", ["Todos", "Sólido", "Líquido"], horizontal=True)
    mm_min, mm_max = float(df["masa_molar"].min()), float(df["masa_molar"].max())
    rango_mm = st.slider("Masa molar (g/mol)", mm_min, mm_max, (mm_min, mm_max), step=1.0)
    solo_bajo = st.checkbox("Solo bajo stock")
    ocultar_caducados = st.toggle("Ocultar caducados")

mascara = df["masa_molar"].between(*rango_mm)
if texto:
    mascara &= (
        df["reactivo"].str.contains(texto, case=False, regex=False)
        | df["formula"].str.contains(texto, case=False, regex=False)
    )
if categorias:
    mascara &= df["categoria"].isin(categorias)
if ubicacion != "Todas":
    mascara &= df["ubicacion"] == ubicacion
if estado != "Todos":
    mascara &= df["estado"] == estado
if solo_bajo:
    mascara &= df["bajo_stock"]
if ocultar_caducados:
    mascara &= ~df["caducado"]

filtrado = df[mascara].reset_index(drop=True)

# ---------------------------------------------------------------- Cabecera
st.title("🧪 Inventario del laboratorio")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Reactivos mostrados", f"{len(filtrado)} / {len(df)}")
c2.metric("Valor del inventario", f"{filtrado['valor'].sum():,.2f} €")
c3.metric("Bajo stock", int(filtrado["bajo_stock"].sum()))
c4.metric("Caducados", int(filtrado["caducado"].sum()))

tab_inv, tab_edit, tab_det, tab_graf, tab_nuevo = st.tabs(
    ["Inventario", "Editar stock", "Detalle", "Gráficos", "Nuevo reactivo"]
)

# ---------------------------------------------------------------- Inventario
with tab_inv:
    evento = st.dataframe(
        filtrado,
        hide_index=True,
        column_order=[
            "picto_url", "id", "reactivo", "formula", "categoria", "pureza_pct",
            "cantidad", "unidad", "stock_minimo", "precio_100", "valor",
            "fecha_caducidad", "ficha_url",
        ],
        column_config={
            "picto_url": st.column_config.ImageColumn("Peligro", width="small"),
            "reactivo": st.column_config.TextColumn("Reactivo", width="medium"),
            "formula": "Fórmula",
            "categoria": "Categoría",
            "pureza_pct": st.column_config.ProgressColumn(
                "Pureza", min_value=90, max_value=100, format="%.1f %%"
            ),
            "cantidad": st.column_config.NumberColumn("Cantidad"),
            "stock_minimo": st.column_config.NumberColumn("Mínimo"),
            "precio_100": st.column_config.NumberColumn("€ / 100", format="%.2f €"),
            "valor": st.column_config.NumberColumn("Valor", format="%.2f €"),
            "fecha_caducidad": st.column_config.DateColumn("Caducidad", format="DD/MM/YYYY"),
            "ficha_url": st.column_config.LinkColumn("Ficha", display_text="📄 Abrir"),
        },
        on_select="rerun",
        selection_mode="multi-row",
        key="tabla_inventario",
    )
    seleccion = evento.selection.rows
    if seleccion:
        ids = filtrado.loc[seleccion, "id"].tolist()
        st.write("Seleccionados:", ", ".join(filtrado.loc[seleccion, "reactivo"]))
        if st.button("🛒 Añadir al pedido"):
            nuevos = [i for i in ids if i not in st.session_state.pedido]
            st.session_state.pedido.extend(nuevos)
            st.toast(f"{len(nuevos)} reactivo(s) añadidos al pedido")

    st.download_button(
        "Descargar tabla filtrada (CSV)",
        filtrado[COLUMNAS_CSV].to_csv(index=False, date_format="%Y-%m-%d"),
        "reactivos_filtrados.csv",
        "text/csv",
    )

# ---------------------------------------------------------------- Editar stock
with tab_edit:
    st.caption("Solo se pueden editar la cantidad y el stock mínimo.")
    editado = st.data_editor(
        filtrado[["id", "reactivo", "unidad", "cantidad", "stock_minimo"]],
        hide_index=True,
        disabled=["id", "reactivo", "unidad"],
        column_config={
            "cantidad": st.column_config.NumberColumn("Cantidad", min_value=0, step=1, required=True),
            "stock_minimo": st.column_config.NumberColumn("Stock mínimo", min_value=0, step=10),
        },
        key="editor_stock",
    )
    cambios = st.session_state.editor_stock["edited_rows"]
    st.write(f"Filas modificadas: {len(cambios)}")

    if st.button("💾 Guardar cambios", disabled=not cambios):
        inv = st.session_state.inventario.set_index("id")
        e = editado.set_index("id")
        inv.loc[e.index, ["cantidad", "stock_minimo"]] = e[["cantidad", "stock_minimo"]]
        st.session_state.inventario = inv.reset_index()
        guardar(st.session_state.inventario)
        del st.session_state["editor_stock"]       # vacía las ediciones pendientes
        st.success("Inventario guardado en reactivos.csv")
        st.rerun()

# ---------------------------------------------------------------- Detalle
with tab_det:
    if filtrado.empty:
        st.info("No hay reactivos con los filtros actuales.")
    else:
        id_sel = st.selectbox(
            "Reactivo",
            filtrado["id"],
            format_func=lambda i: f"{i} · {nombre_de(i)}",
        )
        r = filtrado.set_index("id").loc[id_sel]
        izq, der = st.columns([1, 3])
        with izq:
            st.image(str(STATIC / r["pictograma"]), width=140)
        with der:
            st.subheader(f"{r['reactivo']} ({r['formula']})")
            m1, m2, m3 = st.columns(3)
            m1.metric("Masa molar", f"{r['masa_molar']} g/mol")
            m2.metric(
                "Cantidad",
                f"{r['cantidad']} {r['unidad']}",
                f"{r['cantidad'] - r['stock_minimo']} sobre el mínimo",
            )
            m3.metric("Pureza", f"{r['pureza_pct']} %")
            st.write(f"**Ubicación:** {r['ubicacion']} · **Caduca:** {r['fecha_caducidad']:%d/%m/%Y}")
            if r["caducado"]:
                st.error("Reactivo caducado")
            if r["bajo_stock"]:
                st.warning("Por debajo del stock mínimo")

            ruta_pdf = STATIC / str(r["ficha_pdf"])
            if pd.notna(r["ficha_url"]) and ruta_pdf.is_file():
                b1, b2 = st.columns(2)
                b1.link_button("📄 Abrir ficha", r["ficha_url"])
                with open(ruta_pdf, "rb") as f:
                    b2.download_button("⬇️ Descargar ficha", f, ruta_pdf.name, "application/pdf")
            else:
                st.caption("Este reactivo no tiene ficha.")

# ---------------------------------------------------------------- Gráficos
with tab_graf:
    st.subheader("Valor por categoría (€)")
    st.bar_chart(filtrado.groupby("categoria")["valor"].sum())

    st.subheader("Reactivos bajo stock")
    bajos = filtrado[filtrado["bajo_stock"]][["reactivo", "cantidad", "stock_minimo", "unidad"]]
    if bajos.empty:
        st.success("Ningún reactivo por debajo del mínimo.")
    else:
        st.bar_chart(bajos.set_index("reactivo")[["cantidad", "stock_minimo"]], stack=False)

    st.subheader("Caducidades")

    def color_fila(fila):
        color = "background-color: #ffcdd2" if fila["fecha_caducidad"] < HOY else ""
        return [color] * len(fila)

    caducidades = filtrado.sort_values("fecha_caducidad")[["reactivo", "fecha_caducidad", "ubicacion"]]
    st.dataframe(
        caducidades.style.apply(color_fila, axis=1).format({"fecha_caducidad": "{:%d/%m/%Y}"}),
        hide_index=True,
    )

# ---------------------------------------------------------------- Nuevo reactivo
with tab_nuevo:
    with st.form("nuevo", clear_on_submit=True):
        a, b = st.columns(2)
        nombre = a.text_input("Nombre *")
        formula = b.text_input("Fórmula *")
        categoria = a.selectbox("Categoría", sorted(df["categoria"].unique()))
        estado_n = b.radio("Estado", ["Sólido", "Líquido"], horizontal=True)
        masa = a.number_input("Masa molar (g/mol)", min_value=0.0, value=100.0, step=0.01)
        pureza = b.slider("Pureza (%)", 90.0, 100.0, 99.0, step=0.1)
        cantidad = a.number_input("Cantidad", min_value=0, value=500, step=10)
        minimo = b.number_input("Stock mínimo", min_value=0, value=100, step=10)
        precio = a.number_input("Precio por 100 g/mL (€)", min_value=0.0, value=10.0, step=0.5)
        ubic = b.selectbox("Ubicación", sorted(df["ubicacion"].unique()))
        peligro = a.selectbox("Peligro", sorted(df["peligro"].unique()))
        caducidad = b.date_input("Caducidad", value=date.today().replace(year=date.today().year + 2))
        enviado = st.form_submit_button("Añadir reactivo")

    if enviado:
        if not nombre or not formula:
            st.error("El nombre y la fórmula son obligatorios.")
        else:
            inv = st.session_state.inventario
            nuevo_id = f"R{inv['id'].str[1:].astype(int).max() + 1:03d}"
            pictograma = df.loc[df["peligro"] == peligro, "pictograma"].iloc[0]
            fila = pd.DataFrame([{
                "id": nuevo_id, "reactivo": nombre, "formula": formula, "categoria": categoria,
                "estado": estado_n, "masa_molar": masa, "pureza_pct": pureza, "cantidad": cantidad,
                "unidad": "g" if estado_n == "Sólido" else "mL", "stock_minimo": minimo,
                "precio_100": precio, "ubicacion": ubic, "peligro": peligro,
                "fecha_caducidad": pd.Timestamp(caducidad), "ficha_pdf": None,
                "pictograma": pictograma,
            }])
            st.session_state.inventario = pd.concat([inv, fila], ignore_index=True)
            guardar(st.session_state.inventario)
            st.success(f"Añadido {nombre} con id {nuevo_id}")

# ---------------------------------------------------------------- Pedido
with st.sidebar:
    st.divider()
    with st.expander(f"🛒 Pedido ({len(st.session_state.pedido)})", expanded=True):
        if not st.session_state.pedido:
            st.caption("Selecciona filas en la pestaña Inventario para añadirlas.")
        else:
            ped = df[df["id"].isin(st.session_state.pedido)].copy()
            ped["a_pedir"] = (ped["stock_minimo"] * 2 - ped["cantidad"]).clip(lower=0)
            ped["coste"] = (ped["a_pedir"] / 100 * ped["precio_100"]).round(2)
            for _, p in ped.iterrows():
                st.write(f"• {p['reactivo']}: {p['a_pedir']} {p['unidad']}")
            st.metric("Coste estimado", f"{ped['coste'].sum():.2f} €")
            st.download_button(
                "Descargar pedido",
                ped[["id", "reactivo", "a_pedir", "unidad", "coste"]].to_csv(index=False),
                "pedido.csv",
                "text/csv",
            )
            st.button("Vaciar pedido", on_click=lambda: st.session_state.pedido.clear())
